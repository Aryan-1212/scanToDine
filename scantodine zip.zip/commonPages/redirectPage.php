<?php
function reDirect($path)
{
    header("Location: $path");
}
?>