<?php
require_once("../vendor/autoload.php");

use Minishlink\WebPush\VAPID;

print_r(VAPID::createVapidKeys());

/*
[publicKey] => BHqdBTFT0vRZtITyCBq5JqYWmJGixaro4JVvN4az_oibUXNW9WkIZF-XHClSv7oiRkNqHDk-xlz5S3b3-VIfWD8
[privateKey] => QIl8VxSC5TB8C5u6DBJGr1CvVnLPT3hKOqwYGr-2Pjw
*/