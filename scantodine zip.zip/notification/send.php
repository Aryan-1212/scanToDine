<?php
require_once("../vendor/autoload.php");

use Minishlink\WebPush\Subscription;
use Minishlink\WebPush\WebPush;


$auth = [
    'VAPID' => [
        'subject' => 'mailto:me@website.com', // can be a mailto: or your website address
        'publicKey' => 'BHqdBTFT0vRZtITyCBq5JqYWmJGixaro4JVvN4az_oibUXNW9WkIZF-XHClSv7oiRkNqHDk-xlz5S3b3-VIfWD8', // (recommended) uncompressed public key P-256 encoded in Base64-URL
        'privateKey' => 'QIl8VxSC5TB8C5u6DBJGr1CvVnLPT3hKOqwYGr-2Pjw', // (recommended) in fact the secret multiplier of the private key encoded in Base64-URL 
    ],
];

$webPush = new WebPush($auth);

$report = $webPush->sendOneNotification(
    Subscription::create(json_decode('{"endpoint":"https://fcm.googleapis.com/fcm/send/e1jjOcEFDOw:APA91bERDaAmBDBJ5Ma-X9PWX56djE3nsZBQywqIu4IYJYXYJ4T_-JvJKuR3q6kyrrN9VkMX7LiRazfgNqvytJUvwz1s7XQwiLhs3uGXO8i88Nt3B-ddXVB2bqAefR_IJRngdCZXu464","expirationTime":null,"keys":{"p256dh":"BN3p5aXwAI0T3zlMaj78JvtLAG3s5qxlScJnkurTNSPpQVjyWSDw9JEtGI_W8FzAOPUrW6Zgqs8hMc0mwkIjj3E","auth":"2fTWvmxOwzTwdAvHrLtp0g"}}',true))
    , '{"title":"ScanToDine" , "body":"Order Placed!" , "url":"../adminModule/orders.php"}', ['TTL' => 5000]);

    print_r($report);
